// ES6 CLASS
class Student {
    constructor(id, name, semester, courses){
        this.id = id;
        this.name = name;
        this.semester = semester;
        this.courses = courses;
    }

    display(){
        return `
        <div class="student-card">
            <h3>${this.name}</h3>
            <p><b>ID:</b> ${this.id}</p>
            <p><b>Semester:</b> ${this.semester}</p>
            <p><b>Courses:</b></p>
            <ul>
                ${this.courses.map(course => `<li>${course}</li>`).join("")}
            </ul>
        </div>
        `;
    }
}

const students = [];

// ELEMENTS
const modal = document.getElementById("formModal");
const openBtn = document.getElementById("openFormBtn");
const closeBtn = document.getElementById("closeBtn");
const form = document.getElementById("studentForm");
const container = document.getElementById("studentContainer");

// OPEN FORM
openBtn.onclick = () => modal.style.display = "block";

// CLOSE FORM
closeBtn.onclick = () => modal.style.display = "none";

// SUBMIT FORM
form.addEventListener("submit", function(e){
    e.preventDefault();

    const id = document.getElementById("id").value;
    const name = document.getElementById("name").value;
    const semester = document.getElementById("semester").value;
    const courses = document.getElementById("courses").value.split(",");

    const newStudent = new Student(id, name, semester, courses);

    students.push(newStudent);

    // display
    container.innerHTML += newStudent.display();

    // popup message
    alert("Record Added Successfully!");

    form.reset();
    modal.style.display = "none";
});