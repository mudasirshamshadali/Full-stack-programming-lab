let cart = [];

// REST OPERATOR
function addToCart(...items){
    cart.push(...items);

    // update counter
    document.getElementById("cartCount").innerText = cart.length;

    alert("Item Added to Cart!");
}

// VIEW CART BUTTON
document.getElementById("viewCart").addEventListener("click", showCart);

function showCart(){

    if(cart.length === 0){
        document.getElementById("cartDisplay").innerHTML =
        "<h3>Your cart is empty</h3>";
        return;
    }

    // SPREAD OPERATOR (clone cart)
    const clonedCart = [...cart];

    // DESTRUCTURING
    const [firstItem, ...remainingItems] = clonedCart;

    let html = `
    <h2>Cart Details</h2>
    <p><b>Total Items:</b> ${clonedCart.length}</p>
    <p><b>First Product (Destructuring):</b> ${firstItem}</p>
    <h3>All Products:</h3>
    <ul>
    `;

    clonedCart.forEach(item=>{
        html += `<li>${item}</li>`;
    });

    html += `</ul>`;

    document.getElementById("cartDisplay").innerHTML = html;
}