const loadBtn = document.getElementById("loadBtn");
const statusText = document.getElementById("status");
const usersDiv = document.getElementById("users");

// PROMISE FUNCTION
function fetchUsers(){

    return new Promise((resolve, reject)=>{

        statusText.innerText = "Loading users from server...";
        
        setTimeout(()=>{

            let success = true; // change to false to test error

            if(success){
                const users = [
                    {name:"Ali", age:22},
                    {name:"Ahmed", age:21},
                    {name:"Hassan", age:23},
                    {name:"Usman", age:20}
                ];
                resolve(users);
            }
            else{
                reject("Server Failed! Data not received.");
            }

        },3000);

    });

}

// BUTTON CLICK
loadBtn.addEventListener("click", ()=>{

    fetchUsers()
    .then(users => {

        statusText.innerText = "Users Loaded Successfully!";
        usersDiv.innerHTML = "";

        users.forEach(user=>{
            usersDiv.innerHTML += `
            <div class="user-card">
                <h3>${user.name}</h3>
                <p>Age: ${user.age}</p>
            </div>`;
        });

    })
    .catch(error=>{
        statusText.innerText = error;
        statusText.style.color = "red";
    });

});