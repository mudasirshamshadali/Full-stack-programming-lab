// CLASS
class Student{
    constructor(id,name){
        this.id=id;
        this.name=name;
        this.courses=new Set(); // SET (no duplicates)
    }

    addCourse(course){
        this.courses.add(course);
    }
}

// MAP (store students)
const students=new Map();

const msg=document.getElementById("msg");
const studentList=document.getElementById("studentList");

// ADD STUDENT
document.getElementById("addStudentBtn").addEventListener("click",()=>{

    const id=document.getElementById("sid").value;
    const name=document.getElementById("sname").value;

    if(students.has(id)){
        msg.innerText="Student already exists!";
        msg.style.color="red";
        return;
    }

    const student=new Student(id,name);
    students.set(id,student);

    msg.innerText="Student Added!";
    msg.style.color="green";

    displayStudents();
});

// REGISTER COURSE
document.getElementById("registerCourseBtn").addEventListener("click",()=>{

    const id=document.getElementById("courseSid").value;
    const course=document.getElementById("courseName").value;

    if(!students.has(id)){
        alert("Student not found!");
        return;
    }

    const student=students.get(id);
    student.addCourse(course);

    displayStudents();
});

// DISPLAY
function displayStudents(){

    studentList.innerHTML="";

    for(const [id,student] of students){

        let courses="";
        student.courses.forEach(c=>{
            courses+=`<li>${c}</li>`;
        });

        studentList.innerHTML+=`
        <div class="studentCard">
            <h3>${student.name}</h3>
            <p>ID: ${student.id}</p>
            <p>Courses:</p>
            <ul>${courses}</ul>
        </div>`;
    }
}

// PROMISE (save to server simulation)
function saveToServer(){

    return new Promise((resolve)=>{

        document.getElementById("status").innerText="Saving data to server...";

        setTimeout(()=>{
            resolve("Data Saved Successfully!");
        },2000);

    });
}

document.getElementById("saveBtn").addEventListener("click",()=>{

    saveToServer().then(result=>{
        document.getElementById("status").innerText=result;
        alert(result);
    });

});