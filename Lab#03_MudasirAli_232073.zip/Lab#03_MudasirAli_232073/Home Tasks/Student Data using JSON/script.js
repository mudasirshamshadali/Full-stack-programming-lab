let students=[];

const msg=document.getElementById("msg");
const list=document.getElementById("studentList");
const jsonArea=document.getElementById("jsonOutput");

// ADD STUDENT
document.getElementById("addBtn").addEventListener("click",()=>{

    const name=document.getElementById("name").value;
    const age=document.getElementById("age").value;
    const semester=document.getElementById("semester").value;
    const courses=document.getElementById("courses").value.split(",");

    const student={
        name,
        age,
        semester,
        courses
    };

    students.push(student);

    msg.innerText="Student Added!";
    msg.style.color="green";

    convertToJSON();
    displayStudents();
});

// JSON CONVERT
function convertToJSON(){

    // OBJECT -> JSON STRING
    const jsonString=JSON.stringify(students,null,2);
    jsonArea.value=jsonString;

    // JSON -> OBJECT
    const parsedData=JSON.parse(jsonString);

    console.log(parsedData);
}

// DISPLAY
function displayStudents(){

    list.innerHTML="";

    // forEach loop
    students.forEach(student=>{

        // DESTRUCTURING
        const {name,age,semester,courses}=student;

        list.innerHTML+=`
        <div class="studentCard">
            <h3>${name}</h3>
            <p>Age: ${age}</p>
            <p>Semester: ${semester}</p>
            <p>Courses: ${courses.join(", ")}</p>
        </div>`;
    });
}