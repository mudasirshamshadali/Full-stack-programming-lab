// SET (stores unique values)
const courses = new Set();

const input = document.getElementById("courseInput");
const btn = document.getElementById("addCourseBtn");
const message = document.getElementById("message");
const list = document.getElementById("courseList");
const total = document.getElementById("totalCourses");

btn.addEventListener("click", ()=>{

    const courseName = input.value.trim();

    if(courseName === ""){
        message.style.color = "red";
        message.innerText = "Please enter a course name!";
        return;
    }

    // check duplicate
    if(courses.has(courseName)){
        message.style.color = "red";
        message.innerText = "Course already registered!";
    }
    else{
        courses.add(courseName);

        message.style.color = "green";
        message.innerText = "Course Registered Successfully!";

        displayCourses();
    }

    input.value = "";
});

function displayCourses(){

    list.innerHTML = "";

    // for...of loop
    for(const course of courses){
        list.innerHTML += `<li>${course}</li>`;
    }

    // .size property
    total.innerText = courses.size;
}