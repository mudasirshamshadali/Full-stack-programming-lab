// MAP: key -> product id , value -> product object
const products = new Map();

const pid = document.getElementById("pid");
const pname = document.getElementById("pname");
const pprice = document.getElementById("pprice");
const msg = document.getElementById("msg");
const total = document.getElementById("total");
const list = document.getElementById("productList");

// ADD PRODUCT
document.getElementById("addBtn").addEventListener("click", ()=>{

    const id = pid.value;
    const name = pname.value;
    const price = pprice.value;

    if(id==="" || name==="" || price===""){
        msg.style.color="red";
        msg.innerText="Fill all fields!";
        return;
    }

    if(products.has(id)){
        msg.style.color="red";
        msg.innerText="Product ID already exists!";
        return;
    }

    const product = {id, name, price};

    products.set(id, product);

    msg.style.color="green";
    msg.innerText="Product Added Successfully!";

    displayProducts();
});

// DISPLAY PRODUCTS
function displayProducts(){

    list.innerHTML="";

    for(const [key, value] of products){
        list.innerHTML += `
        <li>
            ID: ${value.id} |
            Name: ${value.name} |
            Price: ${value.price}
        </li>`;
    }

    total.innerText = products.size;
}

// SEARCH
document.getElementById("searchBtn").addEventListener("click", ()=>{

    const sid = document.getElementById("searchId").value;
    const result = document.getElementById("searchResult");

    if(products.has(sid)){
        const p = products.get(sid);
        result.innerText = `Found: ${p.name} - $${p.price}`;
    }
    else{
        result.innerText = "Product Not Found";
        result.style.color="red";
    }
});

// DELETE
document.getElementById("deleteBtn").addEventListener("click", ()=>{

    const did = document.getElementById("deleteId").value;

    if(products.delete(did)){
        alert("Product Deleted!");
        displayProducts();
    }
    else{
        alert("Product ID not found!");
    }
});